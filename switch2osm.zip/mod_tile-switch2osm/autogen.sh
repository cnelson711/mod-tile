#!/bin/sh
autoreconf -vfi